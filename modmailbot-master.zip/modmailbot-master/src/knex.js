const knexConfig = require("./knexConfig");
module.exports = require("knex")(knexConfig);
